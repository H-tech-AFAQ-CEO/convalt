---
name: WebGL preview fallback
description: Why the Convalt landing page keeps a detailed non-WebGL scene fallback.
---

The Replit headless preview can render the page without exposing a usable WebGL context. A 3D scene that is only visible through Three.js may therefore look like a blank gradient during preview even when the interactive version works in a normal browser.

**Why:** Visual verification and low-power/mobile behavior need a meaningful scene even when WebGL is unavailable.

**How to apply:** Preserve the CSS fallback geometry when changing the Three.js scene, and keep it recognizable enough to communicate the energy infrastructure story on its own.