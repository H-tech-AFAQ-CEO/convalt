# Convalt Energy 3D Experience

A cinematic energy infrastructure website with a scroll-driven 3D landing page and accessible 2D internal pages.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/convalt-energy run dev` — run the Convalt Energy website
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/convalt-energy/src/components/energy-scene.tsx` — Three.js scene, pointer parallax, scroll motion, and WebGL fallback markup
- `artifacts/convalt-energy/src/pages/site-pages.tsx` — homepage scroll progress and internal routes
- `artifacts/convalt-energy/src/index.css` — theme, responsive layout, fallback scene, and motion
- `artifacts/convalt-energy/public/assets/` — licensed 3D asset and attribution notes

## Architecture decisions

- The 3D landing scene uses lightweight Three.js primitives for energy infrastructure forms, with one lazily loaded CC0 solar-panel GLB.
- Pointer movement is smoothed into both camera and world/object transforms; touch input does not force a desktop-style cursor interaction.
- WebGL and reduced-motion fallbacks remain visible and recognizable using CSS silhouettes rather than a blank background.
- Internal pages stay 2D and reuse the landing page's typography, palette, and motion language.

## Product

- Full-screen 3D energy landing page with animated solar panels, data-center forms, wind turbines, signal paths, and a moving energy pulse.
- Scroll-driven camera/world movement and cursor-driven parallax.
- Responsive, reduced-motion-aware experience with 2D routes for Projects, Team, Media, Press, Resources, and Contact.

## User preferences

- User asked for more free 3D assets, more animation, and cursor-driven camera/object movement.

## Gotchas

- The Vite config requires `PORT` and `BASE_PATH`; production builds from the shell need `PORT=25168 BASE_PATH=/` or the managed workflow.
- Headless previews may not expose WebGL, so keep the CSS fallback scene intact when changing the Three.js scene.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
