# 3D asset attributions

## Solar Panel

- Creator: Quaternius
- Source: https://poly.pizza/m/ah89Y79JdT
- License: CC0 1.0 Universal
- License text: https://creativecommons.org/publicdomain/zero/1.0/

The asset is used as a lightweight, lazy-loaded solar-panel detail inside the
landing scene. The rest of the scene uses editable Three.js primitives so the
asset can be replaced or extended later without changing the story logic.

## Procedural energy assets

The compute hall, server racks, wind turbines, signal paths, solar field, and
low-power fallback silhouettes are authored in the app from Three.js geometry
and CSS. They are original project code and do not include third-party model
files or external texture licenses.